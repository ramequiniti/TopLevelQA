package Test;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.internal.BaseClassFinder;

import Pages.Pg_AccountActions;
import Pages.Pg_AutomationPractice;


public class MainTest extends utilities.BaseClass {
	WebDriver driver;
	
@BeforeTest
public void driver(){
	driver = driverinvoker();
}

@Test
public void scenarioone() throws IOException, InterruptedException{
	 File file = new File("C:\\Users\\admin\\Desktop\\Lokeshwaran\\automationpractice\\src\\main\\resources\\data\\data.properties");
	 FileInputStream fileInput = fileInput = new FileInputStream(file);;
	 Properties prop = new Properties();
	 prop.load(fileInput);
	Pg_AutomationPractice shopping = new Pg_AutomationPractice(driver);
	shopping.signinaccount(prop.getProperty("email"));
	shopping.personaldetails(prop.getProperty("title"),prop.getProperty("firstname") ,prop.getProperty("lastname") ,prop.getProperty("password") ,prop.getProperty("address"),prop.getProperty("city"),prop.getProperty("state") ,prop.getProperty("zip") ,prop.getProperty("country") ,prop.getProperty("mobile"),prop.getProperty("addressalias"));
	Pg_AccountActions wishlist = new Pg_AccountActions(driver);
	wishlist.addandcheckwishlist( prop.getProperty("firstname")+ " " +prop.getProperty("lastname")); 
}

}
