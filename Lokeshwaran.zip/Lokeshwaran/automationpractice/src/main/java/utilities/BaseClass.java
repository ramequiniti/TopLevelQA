package utilities;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class BaseClass {
	
	public WebDriver driverinvoker(){	
		
	System.setProperty("webdriver.chrome.driver","C:\\Users\\admin\\Desktop\\Lokeshwaran\\automationpractice\\src\\test\\resources\\drivers\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.get("http://www.automationpractice.com/");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	return driver;
	}

}
