package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class Pg_AutomationPractice {
	WebDriver driver;

	public Pg_AutomationPractice(WebDriver driver) {
		this.driver = driver;
	}

	By btnsigin = By.linkText("Sign in");
	By edtcreateaccoountemailid = By.id("email_create");
	By btncreateanaccount = By.id("SubmitCreate");
	By btntilemr = By.id("id_gender1");
	By btntilemrs = By.id("id_gender2");
	By edtperinfofirstname = By.id("customer_firstname");
	By edtperinfolastname = By.id("customer_lastname");
	By edtpassword = By.id("passwd");
	By edtaddress = By.id("address1");
	By edtcity = By.id("city");
	By edtzipcode = By.id("postcode");
	By edtphoneno = By.id("phone_mobile");
	By btnsubmit = By.id("submitAccount");
	By edtalias = By.id("alias");

	public void signinaccount(String email) {
		this.driver.findElement(btnsigin).click();
		this.driver.findElement(edtcreateaccoountemailid).sendKeys(email);
		this.driver.findElement(btncreateanaccount).click();

	}

	public void personaldetails(String title, String firstname,
			String lastname, String password, String address, String city,
			String state, String zip, String country, String mobile,
			String addressalias) throws InterruptedException {
		
		Thread.sleep(2000);
		if (title.equalsIgnoreCase("mr")) {
			this.driver.findElement(btntilemr);
		} else {
			this.driver.findElement(btntilemrs);
		}

		this.driver.findElement(edtperinfofirstname).sendKeys(firstname);
		this.driver.findElement(edtperinfolastname).sendKeys(lastname);
		this.driver.findElement(edtpassword).sendKeys(password);
		this.driver.findElement(edtaddress).sendKeys(address);
		this.driver.findElement(edtcity).sendKeys(city);
		WebElement lststate = this.driver.findElement(By.id("id_state"));
		Select selectstate = new Select(lststate);
		selectstate.selectByVisibleText(state);
		this.driver.findElement(edtzipcode).sendKeys(zip);
		WebElement lstcountry = this.driver.findElement(By.id("id_country"));
		Select selectcountry = new Select(lstcountry);
		selectcountry.selectByVisibleText(country);
		this.driver.findElement(edtphoneno).sendKeys(mobile);
		this.driver.findElement(edtalias).clear();
		this.driver.findElement(edtalias).sendKeys(addressalias);
		this.driver.findElement(btnsubmit).click();

	}

}
