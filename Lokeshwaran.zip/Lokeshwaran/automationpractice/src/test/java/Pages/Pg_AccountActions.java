package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Pg_AccountActions {
	WebDriver driver;

	public Pg_AccountActions(WebDriver driver) {
		this.driver = driver;
	}
	
	By lnkaccountname = By.xpath("//*[@class='header_user_info']/descendant::a[@class='account']");
	By lnkwishlist = By.xpath("//*[@class='lnk_wishlist']/a");
	By lbltopsellers = By.xpath("//*[@id='best-sellers_block_right']/descendant::a[text()='Top sellers']");
	By firstproduct = By.xpath("//li[@class='clearfix'][2]/a");
	By addtowishlist = By.id("wishlist_button");
	By confirmationwishlist = By.xpath("//*[@class='fancybox-error']");
	By closeaddtowishlist = By.xpath("//a[@class='fancybox-item fancybox-close']");

	public void addandcheckwishlist(String username) throws InterruptedException{
		Thread.sleep(3000);
		String accountname = this.driver.findElement(lnkaccountname).getText();
		if (accountname.equalsIgnoreCase(username)){
			System.out.println("Acccount name Matches");
		}
		this.driver.findElement(lnkwishlist).click();
		String topsellercheck = this.driver.findElement(lbltopsellers).getText();
		if (topsellercheck.equalsIgnoreCase("topseller")){
			System.out.println("Top seller are there");
		}
		this.driver.findElement(firstproduct).click();
		this.driver.findElement(addtowishlist).click();
		if ((this.driver.findElement(confirmationwishlist).getText()).equalsIgnoreCase("Added to your wishlist."))
				{
			System.out.println("Wishlist added"); // Need to use reporters here inspite of syso
		}
		this.driver.findElement(closeaddtowishlist).click();
		this.driver.findElement(lnkaccountname).click();
		this.driver.findElement(lnkwishlist).click();
				
	}
	
	

}
