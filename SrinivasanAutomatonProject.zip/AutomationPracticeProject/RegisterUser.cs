﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using NUnit.Framework;
using OpenQA.Selenium.Support.UI;
using System.Linq;
using System.Threading;

namespace AutomationPracticeProject
{
    [TestClass]
    public class RegisterUser
    {
        public IWebDriver driver;
        public By signInBtn = By.XPath("//a[contains(text(),'Sign in')]");
        public By emailBox = By.CssSelector("#email_create");
        public By firstName = By.CssSelector("#customer_firstname");
        public By createAccBtn = By.CssSelector("#SubmitCreate");
        public By genderBtn = By.CssSelector("#id_gender1");
        public By lastName = By.CssSelector("#customer_lastname");
        public By passwordBox = By.CssSelector("#passwd");
        public By addressFirstName = By.CssSelector("#firstname");
        public By addressLastName = By.CssSelector("#lastname");
        public By address1 = By.CssSelector("#address1");
        public By city = By.CssSelector("#city");
        public By stateDrpdwn = By.CssSelector("#id_state");
        public By zipcode = By.CssSelector("#postcode");
        public By countryDrpDwn = By.CssSelector("#id_country");
        public By phone = By.CssSelector("#phone_mobile");
        public By alias = By.CssSelector("#alias");
        public By register = By.CssSelector("#submitAccount");
        public By cart = By.CssSelector("a[title='View my shopping cart']");
        public By displayName = By.CssSelector("a[title='View my customer account'] span");
        public By myWishListLink = By.CssSelector("a[title='My wishlists'] span");
        public By topSellers = By.CssSelector("a[title='View a top sellers products']");
        public By saleItem = By.XPath("//div[@class='product-content']//a");
        public By wishListBtn = By.CssSelector("#wishlist_button");
        public By addedToWishList = By.XPath("//*[@id='product']/div[2]/div/div/div/div/p");
        public By close = By.CssSelector("a[title='Close']");

        [SetUp]
        public void TestSetup()
        {
            string URL = "http://automationpractice.com/index.php";
            driver = new ChromeDriver(@"C:\Users\Admin\Desktop\chromedriver_win32");
            driver.Navigate().GoToUrl(URL);
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
        }

        [Test]
        public void UserDetails()
        {
            string email = RandomString(4) + "@gmail.com";
            WebDriverWait wait = new WebDriverWait(driver,TimeSpan.FromSeconds(10));
            driver.FindElement(signInBtn).Click();
            wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//img[@class='logo img-responsive']")));

            driver.FindElement(emailBox).SendKeys(email);
            driver.FindElement(createAccBtn).Click();
            wait.Until(ExpectedConditions.ElementIsVisible(firstName));
            Thread.Sleep(3000);
            driver.FindElement(genderBtn).Click();
            driver.FindElement(firstName).SendKeys("testname");
            driver.FindElement(lastName).SendKeys("testname");
            driver.FindElement(passwordBox).SendKeys("12345");
            driver.FindElement(addressFirstName).SendKeys("abcd");
            driver.FindElement(addressLastName).SendKeys("abcd");
            driver.FindElement(address1).SendKeys("abcd");
            driver.FindElement(city).SendKeys("abcd");

            var state = driver.FindElement(stateDrpdwn);
            var selectState = new SelectElement(state);
            selectState.SelectByValue("1");

            driver.FindElement(zipcode).SendKeys("00000");

            var country = driver.FindElement(countryDrpDwn);
            var selectCountry = new SelectElement(country);
            selectCountry.SelectByValue("21");

            driver.FindElement(phone).SendKeys("1234567890");
            driver.FindElement(register).Click();
            wait.Until(ExpectedConditions.ElementIsVisible(myWishListLink));
            NUnit.Framework.Assert.IsTrue(driver.FindElement(displayName).Displayed, "Name is displayed" );
            NUnit.Framework.Assert.IsTrue(driver.FindElement(myWishListLink).Displayed, "WishList Link is displayed");

            driver.FindElement(myWishListLink).Click();
            wait.Until(ExpectedConditions.ElementIsVisible(topSellers));
            driver.FindElement(saleItem).Click();

            wait.Until(ExpectedConditions.ElementIsVisible(wishListBtn));
            driver.FindElement(wishListBtn).Click();

            wait.Until(ExpectedConditions.ElementIsVisible(close));
            driver.FindElement(close).Click();

            driver.Navigate().Back();

        }

       [TearDown]
       public void TestTearDown()
        {
            //driver.Quit();
        }

        private static Random random = new Random();
        public static string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }
    }
}
