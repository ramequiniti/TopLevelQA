package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class US10001 {

	public static void main(String[] args) {

		WebDriver driver = new ChromeDriver();

		US10001 objUS = new US10001();

		/*
		 * Passed the data in a parameterized approach - we can use excel to
		 * have data passed dynamically OR we can also use TestNG wtih
		 * DataProvider and have invocation count on single testmethod to reduce
		 * code redundancy
		 */

		objUS.test_1(driver, objUS, "abcd@gmail.com", "John", "Steve",
				"pass@2015", "NorthStreet1", "Alabama", "12345", "1234567890");

		objUS.test_2(driver, objUS, "abcde@gmail.com", "Peter", "Steve",
				"pass@2016", "NorthStreet2", "Virginia", "12555", "2134567890");

		objUS.test_3(driver, objUS, "abcd@gmail.com", "Mark", "Steve",
				"pass@2017", "NorthStreet3", "Alaska", "09345", "9034567890");

		objUS.teardown(driver);
	}

	/*
	 * TESTs are written here - this can be hidden by having a seperate test
	 * class and have all the execution flow there
	 */
	public void test_1(WebDriver driver, US10001 objUS, String mailID,
			String Firstname, String Lastname, String Password, String Address,
			String State, String Zip, String Phone) {

		objUS.launchApp(driver);
		objUS.AddAccount(driver);
		objUS.fillForm(driver, mailID, Firstname, Lastname, Password, Address,
				State, Zip, Phone);
		objUS.ViewWishList(driver);
		objUS.AddProducttoWishList(driver);
		objUS.ValidateWishList(driver);
	}

	public void test_2(WebDriver driver, US10001 objUS, String mailID,
			String Firstname, String Lastname, String Password, String Address,
			String State, String Zip, String Phone) {

		objUS.launchApp(driver);
		objUS.AddAccount(driver);
		objUS.fillForm(driver, mailID, Firstname, Lastname, Password, Address,
				State, Zip, Phone);
		objUS.ViewWishList(driver);
		objUS.AddProducttoWishList(driver);
		objUS.ValidateWishList(driver);
	}

	public void test_3(WebDriver driver, US10001 objUS, String mailID,
			String Firstname, String Lastname, String Password, String Address,
			String State, String Zip, String Phone) {

		objUS.launchApp(driver);
		objUS.AddAccount(driver);
		objUS.fillForm(driver, mailID, Firstname, Lastname, Password, Address,
				State, Zip, Phone);
		objUS.ViewWishList(driver);
		objUS.AddProducttoWishList(driver);
		objUS.ValidateWishList(driver);
	}

	/*
	 * Page Functions are written here - these can be abstracted by having a
	 * dedicated package and have all the page functions and its implementations
	 * over there and just consume the page functionalities in the test classes
	 * based ion the execution flow
	 */

	public void AddAccount(WebDriver driver) {

		driver.findElement(
				By.xpath("//div[@class='header_user_info']/a[@class='login']"))
				.click();
	}

	public void fillForm(WebDriver driver, String mailID, String Firstname,
			String Lastname, String Password, String Address, String State,
			String Zip, String Phone) {
		sendtext(driver, "//*[@id='email_create']", mailID);
		click(driver, "//*[@id='email_create']");
		click(driver, "//*[@id='uniform-id_gender1]/span");
		sendtext(driver, "//*[@id='customer_firstname']", Firstname);
		sendtext(driver, "//*[@id='customer_lastname']", Lastname);
		sendtext(driver, "//*[@id='passwd']", Password);
		sendtext(driver, "//*[@id='address1']", Address);
		selectValue(driver, "//*[@id='id_state']", State);
		sendtext(driver, "//*[@id='postcode']", Zip);
		sendtext(driver, "//*[@id='phone_mobile']", Phone);
		click(driver, "//*[@id='submitAccount']");
		String MyAccoutnName = driver
				.findElement(
						By.xpath("//div[@class='header_user_info']/a[@class='account']"))
				.getText();
		if (MyAccoutnName.equalsIgnoreCase(Firstname + " " + Lastname)) {
			System.out.println("name is present on the Landing page");
		} else {
			System.out
					.println("name should be present on the Landing page but MISSING");
		}

	}

	public void ViewWishList(WebDriver driver) {
		click(driver,
				"//*[@id='center_column']//ul/li[@class='lnk_wishlist']/a");
	}

	public void AddProducttoWishList(WebDriver driver) {

		String topSellerTitle = driver
				.findElement(
						By.xpath("//*[@id='best-sellers_block_right']/h4[@class='title_block']/a"))
				.getText();

		if (topSellerTitle.equalsIgnoreCase("TOP SELLERS")) {
			System.out.println("TOP SELLERS is present");
			click(driver, "//*[@id='best-sellers_block_right']//ul/li[1]/a");
			click(driver, "//*[@id='wishlist_button']");

			click(driver, "//*[@id='product']/div[2]/div/div/a");

		} else {
			System.out.println("TOP SELLERS block is not found");
		}

	}

	public boolean ValidateWishList(WebDriver driver) {

		// Clicks on the AccountName to return to MyAccount Page
		click(driver, "//div[@class='header_user_info']/a[@class='account']");

		// Clicks on wishlist and validate a new row is added to the wishlist
		// table
		click(driver,
				"//*[@id='center_column']//ul/li[@class='lnk_wishlist']/a");
		WebElement wishlistBool = driver.findElement(By
				.xpath("//tr[contains(@id,'wishlist_')]"));
		if (wishlistBool != null) {
			return true;
		} else
			return false;

	}

	/*
	 * utilities can be hidden from here to a dedicated package and consume the
	 * function in the page functions
	 */

	public void teardown(WebDriver driver) {
		driver.close();
	}

	public void launchApp(WebDriver driver) {
		driver.get("http://automationpractice.com/");
	}

	public void sendtext(WebDriver driver, String xpath, String value) {
		driver.findElement(By.xpath(xpath)).sendKeys(value);
	}

	public void sendtext(WebDriver driver, String xpath, CharSequence[] value) {
		driver.findElement(By.xpath(xpath)).sendKeys(value);
	}

	public void click(WebDriver driver, String xpath) {
		driver.findElement(By.xpath(xpath)).click();
	}

	public void selectValue(WebDriver driver, String xpath, String Value) {
		WebElement selectElem = driver.findElement(By.xpath(xpath));
		new Select(selectElem).selectByVisibleText(Value);
	}
}
