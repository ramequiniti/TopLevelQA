package pages;

public class LandingPage {

}
