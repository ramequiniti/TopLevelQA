﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Threading.Tasks;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using OpenQA.Selenium.Internal;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using excel = Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;

namespace manikandanAutomationConsoleexe
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamWriter log;
            log = new StreamWriter("logfile.txt");
            log.WriteLine(DateTime.Now);
            log.WriteLine();
            string Email=null, UserName=null, Password=null, Firstname=null, LastName=null, address=null, zip=null,city=null, mobile="8012371209";

            Excel.Application ExcelApp = new Excel.Application();
            string filepath = @Directory.GetCurrentDirectory() + "\\US10001.xlsx";
            Excel.Workbook excelWorkbook = ExcelApp.Workbooks.Open(filepath);
            string ExcelWorkbookname = excelWorkbook.Name;
            int worksheetcount = excelWorkbook.Worksheets.Count;
            Excel.Worksheet excelworksheet = (Excel.Worksheet)excelWorkbook.Worksheets[1];

            try
            {
                string url = "http://automationpractice.com/index.php";
                string loginlinkelemnet = ".login";
                By EmailBoxRegPage = By.Id("email_create");

                excel.Range excelRange = excelworksheet.UsedRange;
                int Userrows = excelRange.Rows.Count;
                int Datecolumn = excelRange.Columns.Count;
                for (int user = 2; user <= Userrows; user++)
                {
                    string timezone = DateTime.Now.ToString("HHmmss");
                    Email = ((Excel.Range)excelworksheet.Cells[user, 1]).Value + timezone + "@gmail.com";
                    UserName = ((Excel.Range)excelworksheet.Cells[user, 2]).Value;
                    Password = ((Excel.Range)excelworksheet.Cells[user, 3]).Value;
                    Firstname = ((Excel.Range)excelworksheet.Cells[user, 4]).Value;
                    LastName = Firstname;
                    address = ((Excel.Range)excelworksheet.Cells[user, 5]).Value;
                    city = ((Excel.Range)excelworksheet.Cells[user, 6]).Value;
                    zip = ((Excel.Range)excelworksheet.Cells[user, 7]).Value;

                    IWebDriver chromeDriver = new ChromeDriver();
                    chromeDriver.Navigate().GoToUrl(url);
                    chromeDriver.Manage().Window.Maximize();
                    chromeDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);

                    //Validation 1 - Link should be there for Login
                    IWebElement loginLink = chromeDriver.FindElement(By.CssSelector(loginlinkelemnet));
                    if (loginLink.Displayed)
                    {
                        log.WriteLine("Login link displayed");
                    }
                    else
                    {
                        log.WriteLine("Login link not displayed");
                    }

                    loginLink.Click();
                    //Check the sigh up page created
                    chromeDriver.Title.Equals("Login - My Store");

                    //Set Email for login
                    chromeDriver.FindElement(EmailBoxRegPage).SendKeys(Email);
                    chromeDriver.FindElement(By.Id("SubmitCreate")).Click();

                    IWebElement registerButton = chromeDriver.FindElement(By.Id("submitAccount"));

                    //Check regtser page displayed
                    if (registerButton.Displayed)
                    {
                        log.WriteLine("Log regsiter page is created");
                    }

                    //Regter form 
                    chromeDriver.FindElement(By.Id("customer_firstname")).SendKeys(Firstname);
                    chromeDriver.FindElement(By.Id("customer_lastname")).SendKeys(LastName);
                    //chromeDriver.FindElement(By.Id("email")).SendKeys("");
                    //chromeDriver.FindElement(By.Id("email")).SendKeys(Email);
                    chromeDriver.FindElement(By.Id("passwd")).SendKeys(Password);
                    chromeDriver.FindElement(By.Id("firstname")).SendKeys(Firstname);
                    chromeDriver.FindElement(By.Id("address1")).SendKeys(address);
                    chromeDriver.FindElement(By.Id("city")).SendKeys(city);
                    SelectElement stateDropDown = new SelectElement(chromeDriver.FindElement(By.Id("id_state")));
                    stateDropDown.SelectByText("Alaska");
                    chromeDriver.FindElement(By.Id("postcode")).SendKeys("00000");
                    SelectElement CountryDropDown = new SelectElement(chromeDriver.FindElement(By.Id("id_country")));
                    CountryDropDown.SelectByText("United States");
                    chromeDriver.FindElement(By.Id("phone_mobile")).SendKeys(mobile);
                    chromeDriver.FindElement(By.Id("submitAccount")).Click();

                    //Verify account login Success
                    if (!chromeDriver.Title.Equals("My account - My Store"))
                    {
                        log.WriteLine("Not able to register the user");
                    }

                    //User name at top right corner
                    IWebElement MyAccount = chromeDriver.FindElement(By.CssSelector(".account"));
                    if (chromeDriver.FindElement(By.CssSelector(".account")).Text == UserName)
                    {
                        log.WriteLine("User name is displayed at the top right corner");
                    }
                    else
                    {
                        log.WriteLine("User name is not displayed at the top right corner");
                    }


                    //Wishlist displayed
                    IWebElement wishlistlink = chromeDriver.FindElement(By.CssSelector(".lnk_wishlist"));
                    if (!wishlistlink.Displayed)
                    {
                        log.WriteLine("Not able to find the Wishlist link");
                    }
                    //Wishlist click
                    wishlistlink.Click();

                    //Top seller Panel
                    if (!chromeDriver.FindElement(By.Id("best-sellers_block_right")).Displayed)
                    {
                        log.WriteLine("Not able to find the best seller panel");
                    }


                    IList<IWebElement> TopsellerList = chromeDriver.FindElements(By.CssSelector(".products-block-image"));
                    TopsellerList[0].Click();


                    //Get the Product name for confirmaation at Wishist page.
                    string productname = chromeDriver.FindElement(By.CssSelector("div h1[itemprop='name']")).Text;


                    IWebElement wishlistLinkatProductPage = chromeDriver.FindElement(By.Id("wishlist_button"));
                    if (!wishlistLinkatProductPage.Displayed)
                    {
                        log.WriteLine("Unable to find the Wishlist item under the Add to cart button");
                    }

                    wishlistLinkatProductPage.Click();


                    IWebElement WishListConfirmationPopUp = chromeDriver.FindElement(By.CssSelector(".fancybox-overlay .fancybox-error"));
                    if (!WishListConfirmationPopUp.Text.Equals("Added to your wishlist."))
                    {
                        log.WriteLine("Added to your wishlist. Pop up is not displayed in the ");
                    }

                    //Close the Pop.
                    chromeDriver.FindElement(By.CssSelector(".fancybox-close")).Click();

                    //Navigate to the My Accunt --> Wishlist
                    MyAccount = chromeDriver.FindElement(By.CssSelector(".account"));
                    MyAccount.Click();

                    wishlistlink = chromeDriver.FindElement(By.CssSelector(".lnk_wishlist"));
                    wishlistlink.Click();


                    IWebElement viewLinkforWishList = chromeDriver.FindElements(By.CssSelector(".block-center a"))[1];
                    viewLinkforWishList.Click();


                    //WIshlist elemnet List
                    IList<string> wishlistitemsName = new List<string>();
                    IList<IWebElement> wishlistitems = chromeDriver.FindElements(By.CssSelector(".wishlistLinkTop .product-name"));
                    foreach (IWebElement item in wishlistitems)
                    {
                        wishlistitemsName.Add(item.Text);
                    }

                    if (wishlistitemsName.Any(name => name.Contains(productname)))
                    {
                        log.WriteLine("Product is listed in the Wishlist page");
                    }
                    else
                    {
                        log.WriteLine("Product is listed in the Wishlist page");
                    }

                    log.Close();
                    chromeDriver.Quit();
                }

            }
            catch( Exception ex)
            {
                log.Write(ex.Message.ToString());
                log.Close();
            }
            finally
            {
                excelWorkbook.Close(true, null, null);
                ExcelApp.Quit();
            }


        }
    }
}
