﻿namespace Automationproject
{
    internal class WebElement
    {
    }
}