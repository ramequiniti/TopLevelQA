﻿using NUnit.Framework;
using NUnit.Framework.Internal;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Automationproject
{
    class Automationpractice
    {
        // Launch Browser and hit the url

        public static IWebDriver driver;
        public String mailid = "alphaori001@gmail.com";
        public String password = "Hello@123";

        [OneTimeSetUp]
        public void LaunchApplication()
        {
            //Launching the applciation
            driver = new ChromeDriver();
            driver.Navigate().GoToUrl("http://automationpractice.com");
            driver.Manage().Window.Maximize();

        }
        [Test, Order(1)]
        public void Signin()
        {
            //clicking sigin Button
            try
            {
                driver.FindElement(By.XPath("//header[@id='header']/div[2]/div/div/nav/div[1]/a")).Click();
                Thread.Sleep(1500);

                //Sigin to the Account..
                driver.FindElement(By.XPath("//input[@id='email']")).SendKeys(mailid);
                driver.FindElement(By.XPath("//input[@id='passwd']")).SendKeys(password);
                driver.FindElement(By.XPath("//button[@id='SubmitLogin']")).Click();
                Thread.Sleep(1500);
                try
                {
                    Boolean check = driver.FindElement(By.XPath("//li[contains(text(),'Authentication failed')]")).Displayed;
                    if (check)
                    {
                        //Creating new Account..

                        driver.FindElement(By.XPath("//input[@id='email_create']")).SendKeys(mailid);
                        driver.FindElement(By.XPath("//button[@id='SubmitCreate']")).Click();

                        Thread.Sleep(1500);
                        driver.FindElement(By.XPath("//input[@id='id_gender1']")).Click();

                        driver.FindElement(By.XPath("//input[@id='customer_firstname']")).SendKeys("Gurunathan");
                        driver.FindElement(By.XPath("//input[@id='customer_lastname']")).SendKeys("Arumugam");
                        driver.FindElement(By.XPath("//input[@id='passwd']")).SendKeys(password);
                        driver.FindElement(By.XPath("//input[@id='address1']")).SendKeys("Rajiv Gandhi Salai");
                        driver.FindElement(By.XPath("//input[@id='city']")).SendKeys("Chennai");

                        SelectElement select = new SelectElement(driver.FindElement(By.Id("id_state")));
                        select.SelectByValue("2");
                        Thread.Sleep(1500);

                        driver.FindElement(By.XPath("//input[@id='postcode']")).SendKeys("54654");
                        driver.FindElement(By.XPath("//input[@id='phone_mobile']")).SendKeys("2564566");
                        driver.FindElement(By.XPath("//input[@id='alias']")).SendKeys("test@gmail.com");
                        driver.FindElement(By.XPath("//button[@id='submitAccount']")).Click();

                        Thread.Sleep(2500);
                        //Sigin to the Account..
                        driver.FindElement(By.XPath("//input[@id='email']")).SendKeys(mailid);
                        driver.FindElement(By.XPath("//input[@id='passwd']")).SendKeys(password);
                        driver.FindElement(By.XPath("//button[@id='SubmitLogin']")).Click();
                        Thread.Sleep(1500);
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Already Addeed");
                }

            }
            catch (Exception)
            {
                Assert.IsTrue(false);
            }
        }

        [Test, Order(2)]
        public void VerifyMyName()
        {
            //VerifyNyName
            try
            {
                driver.FindElement(By.XPath("//*[@id='center_column']/div/div[1]/ul/li[4]/a/span")).Click();
                Thread.Sleep(2500);
                String firstname= driver.FindElement(By.XPath("//*[@id='firstname']")).GetAttribute("value");
                String latname = driver.FindElement(By.XPath("//*[@id='lastname']")).GetAttribute("value");
                String displayname = driver.FindElement(By.XPath("//*[@id='header']/div[2]/div/div/nav/div[1]/a/span")).Text;

                if (displayname.Equals(firstname + " " + latname, StringComparison.OrdinalIgnoreCase))
                  
                {
                    Console.WriteLine("Sucessfully display the name");
                }

                driver.FindElement(By.XPath("//*[@id='header']/div[2]/div/div/nav/div[1]/a/span")).Click();
                Thread.Sleep(5000);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }

        [Test, Order(3)]
        public void Mywishlist()
        {
            //veify able to click Mywishlist link  
            try
            {
                driver.FindElement(By.XPath("//*[@id='center_column']/div/div[2]/ul/li/a/span")).Click();
                Thread.Sleep(5000);
                Console.WriteLine("Sucessfully able to click on wishlist link");

                String whistlistpage = driver.FindElement(By.XPath("//*[@id='mywishlist']/h1")).Text;
                if (whistlistpage.Equals("My wishlists", StringComparison.OrdinalIgnoreCase))

                {
                    Console.WriteLine("Sucessfully verify the Mywhishlist page");
                }
                
               
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }


        }

        [Test, Order(4)]
        public void AddedWishlist()
        {
            try
            {
                driver.FindElement(By.XPath("//input[@id='search_query_top']")).SendKeys("dress");
                driver.FindElement(By.XPath("//form[@id='searchbox']/button")).Click();
                Thread.Sleep(2500);
                String itemfound = "";
                int count = driver.FindElements(By.XPath("//*[@id='center_column']/ul/li")).Count;
                {
                    if (count == 0)
                    {
                        Console.WriteLine("there is no item found to add to whishlist");
                    }
                    else
                    {
                        for (int index = 1; index <= count;)
                        {
                            String srcText = driver.FindElement(By.XPath("//*[@id='center_column']/ul/li[" + index + "]/div/div/div/a[1]/img")).GetAttribute("src");
                            String title = driver.FindElement(By.XPath("//*[@id='center_column']/ul/li[" + index + "]/div/div/div/a[1]/img")).GetAttribute("Title");
                            String description = driver.FindElement(By.XPath("//*[@id='center_column']/ul/li[1]//p")).Text;
                            String price = driver.FindElement(By.XPath("//*[@id='center_column']/ul/li[" + index + "]/div/div[2]/div[1]/span[2]")).Text;
                            driver.FindElement(By.XPath("//*[@id='center_column']/ul/li[" + index + "]/div/div/div/a[1]/img")).Click();

                            Thread.Sleep(4500);
                            driver.SwitchTo().Frame(driver.FindElement(By.XPath("//iframe[@class='fancybox-iframe']")));
                            Thread.Sleep(1500);
                            driver.FindElement(By.XPath("//a[@id='wishlist_button']")).Click();
                            Thread.Sleep(1500);
                            String txt = driver.FindElement(By.XPath("//*[@id='product']/div[2]/div/div/div/div/p")).Text;
                            if (txt.Equals("Added to your wishlist.", StringComparison.OrdinalIgnoreCase))
                            {
                                Console.WriteLine("Added to Whishlist");


                                driver.SwitchTo().DefaultContent();
                                Thread.Sleep(1500);

                                driver.FindElement(By.XPath("//body[@id='search']//a[@title='Close']")).Click();
                                //clicking cutomer link in header
                                driver.FindElement(By.XPath("//a[@title='View my customer account']")).Click();
                                Thread.Sleep(2500);
                                //clickin whislist
                                driver.FindElement(By.XPath("//span[text()='My wishlists']")).Click();
                                Thread.Sleep(2500);
                                //clicking view Button
                                driver.FindElement(By.XPath("//div[@id='block-history']/table/tbody//td[5]/a")).Click();
                                Thread.Sleep(1500);
                                int whislistcnt = driver.FindElements(By.XPath("//*[@id='block-order-detail']/div/div/ul/li")).Count;
                                if (whislistcnt == 0)
                                {
                                    Console.WriteLine("No item found in whislist");
                                    Assert.IsTrue(false);
                                }
                                else
                                {
                                    for (int whishindex = 1; whishindex <= whislistcnt; whishindex++)
                                    {
                                        String src1 = driver.FindElement(By.XPath("//*[@id='block-order-detail']/div/div/ul/li[" + whishindex + "]/div/div/div/a/img")).GetAttribute("src");
                                        if (src1.Equals(srcText, StringComparison.OrdinalIgnoreCase))
                                        {
                                            Console.WriteLine("Succesfully Item Found in whislist");
                                            driver.FindElement(By.XPath("//*[@id='block-order-detail']/div/div/ul/li[" + whishindex + "]/div/div//a[@title='Delete']")).Click();
                                            Thread.Sleep(1500);
                                            itemfound = "yes";
                                            break;
                                        }
                                    }
                                }
                                if (itemfound.Equals("yes"))
                                    break;


                            }




                        }
                    }
                }





            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

    }
}

