package buisnessFlows;

import Testng.TestScripts;
import webelements.CreateAccount_PageElements;
import webelements.Signin_Pageelements;

public class CreateAccountpage extends TestScripts implements Signin_Pageelements {

	
	public static void Fill() throws InterruptedException{	
		//WebDriver driver=TestScripts.driver;
		driver.findElement(CreateAccount_PageElements.EmailId_textbox).isDisplayed();
		driver.findElement(CreateAccount_PageElements.EmailId_textbox).sendKeys("Test@gmail.com");
		driver.findElement(CreateAccount_PageElements.CreateAccount_link).click();
		driver.findElement(CreateAccount_PageElements.CustomerFirstName_textbox).sendKeys("a");
		
		
		
		
		}
}
