package buisnessFlows;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import Testng.TestScripts;
import webelements.Signin_Pageelements;

import java.lang.*;

public class Signinpage extends TestScripts implements Signin_Pageelements{


	public static void login(){	
		//WebDriver driver=TestScripts.driver;
		driver.findElement(Signin_Pageelements.Signin_link).click();
		
		
		
		
		}
	//}
}
