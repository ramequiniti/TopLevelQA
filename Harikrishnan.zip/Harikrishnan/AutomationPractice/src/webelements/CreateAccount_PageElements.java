package webelements;

import org.openqa.selenium.By;

public interface CreateAccount_PageElements {
	
	public static By EmailId_textbox=By.id("email_create");
	public static By CreateAccount_link=By.linkText("Create an account");

	
	//Personal Information Lists
	
	public static By CustomerFirstName_textbox=By.id("customer_firstname");
	public static By CustomerLastName_textbox=By.id("customer_lastname");
	public static By Email_textbox=By.id("email");
	public static By Password_textbox=By.id("passwd");
	
	
	public static By Days_dropdown=By.id("days");
	public static By Months_dropdown=By.id("months");
	public static By Years_dropdown=By.id("years");
	
	//*********Address Section***************
	
	
	public static By FirstName_textbox=By.id("firstname");
	public static By LastName_textbox=By.id("lastname");
	public static By Company_textbox=By.id("company");
	public static By Address1_textbox=By.id("address1");
	public static By Address2_textbox=By.id("address2");
	
	public static By City_textbox=By.id("city");
	public static By PostCode_textbox=By.id("postcode");
	public static By Other_textbox=By.id("other");
	public static By Phone_textbox=By.id("phone");
	public static By Mobilephone_textbox=By.id("phone_mobile");
	public static By Alias_textbox=By.id("alias");
	
	public static By State_dropdown=By.id("id_state");
	public static By Country_dropdown=By.id("id_country");
	
	//Buttons
	
	public static By Register_button=By.id("submitAccount");
}
