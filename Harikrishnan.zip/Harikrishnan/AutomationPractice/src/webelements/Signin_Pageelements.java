package webelements;

import org.openqa.selenium.By;

public interface Signin_Pageelements {

	
	public static By Signin_link=By.cssSelector(".login");
	
}
