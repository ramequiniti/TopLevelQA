package Testng;

import static org.junit.Assert.*;
import buisnessFlows.CreateAccountpage;
import buisnessFlows.Signinpage;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import webelements.Signin_Pageelements;

public class TestScripts {
protected static WebDriver driver;
	@BeforeClass
	public void Setup()
	{
		System.setProperty("webdriver.chrome.driver", "C:/Users/Admin/Desktop/UIAutomation/packages/Selenium.Chrome.WebDriver.2.42/driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://automationpractice.com/index.php");
		}



	//@Test
	public void Login() throws InterruptedException {
		
		Signinpage.login();
		//CreateAccountpage.Fill();
	}
	
	@Test
	public void mand() throws InterruptedException {
		
		Signinpage.login();
		CreateAccountpage.Fill();
	}

}
