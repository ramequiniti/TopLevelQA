﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UIAutomation.PageObjects
{
    public class CustomerVsCartPage
    {
        public IWebDriver driver;
        public void ClickSignInButton()
        {
            IWebElement SigninButton = driver.FindElement(By.XPath("//*[@id='index']"));
            SigninButton.Click();
        }

        public void EnterEmailAddress(string EmailAddress)
        {
            IWebElement Email = driver.FindElement(By.XPath("//*[@id='index']"));
            Email.Click();
            Email.SendKeys(EmailAddress);
        }

        public void EnterRegistarateDetails(string Title, string FN, string SN, string Address, string City, string State, string ZipCode, string Country, string Mobile)
        {
            IWebElement Field1 = driver.FindElement(By.XPath("//*[@id='index']"));
            Field1.Click();
            Field1.SendKeys(Title);

            IWebElement Field2 = driver.FindElement(By.XPath("//*[@id='index']"));
            Field2.Click();
            Field2.SendKeys(FN);

            IWebElement Field3 = driver.FindElement(By.XPath("//*[@id='index']"));
            Field3.Click();
            Field3.SendKeys(SN);


            IWebElement Field4 = driver.FindElement(By.XPath("//*[@id='index']"));
            Field4.Click();
            Field4.SendKeys(Address);


            IWebElement Field5 = driver.FindElement(By.XPath("//*[@id='index']"));
            Field5.Click();
            Field5.SendKeys(City);

            IWebElement Field6 = driver.FindElement(By.XPath("//*[@id='index']"));
            Field6.Click();
            Field6.SendKeys(ZipCode);



            IWebElement Field7 = driver.FindElement(By.XPath("//*[@id='index']"));
            Field7.Click();
            Field7.SendKeys(Country);

            IWebElement Field8 = driver.FindElement(By.XPath("//*[@id='index']"));
            Field8.Click();
            Field8.SendKeys(Mobile);

        }


        public void ValidateNavigation()
        {
            string MyAccountURL = driver.Url;
            string ExpectedURL = "";
            Assert.AreEqual(MyAccountURL, ExpectedURL);
        }
    }
}

