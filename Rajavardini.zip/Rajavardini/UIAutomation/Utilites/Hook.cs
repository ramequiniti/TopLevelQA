﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace UIAutomation.Utilites
{
    [Binding]
    public class Hook
    {
        public IWebDriver Driver;

        [BeforeScenario]
        public void LaunchBrowser()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("http://automationpractice.com/index.php");
            Thread.Sleep(5000);

        }


    }
}
