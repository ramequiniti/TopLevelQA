﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using UIAutomation.PageObjects;

namespace UIAutomation.Acceptance_Test
{
    [Binding]
    public class CustomerVsCartStep
    {
        CustomerVsCartPage page1 = new CustomerVsCartPage();

        [Given(@"the user navigate to Signin Page")]
        public void GivenTheUserNavigateToSigninPage()
        {
            page1.ClickSignInButton();
        }

        [Given(@"Enter the Email Address(.*)")]
        public void GivenEnterTheEmailAddress(string Email)
        {
            page1.EnterEmailAddress(Email);
        }

        [When(@"the user register all their details(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*)")]
        public void WhenTheUserRegisterAllTheirDetails(string Title,string FN, string SN, string Address, string City, string State, string ZipCode, string Country, string Mobile)
        {
            page1.EnterRegistarateDetails(Title,FN,SN,Address,City,State,ZipCode,Country,Mobile);
        }

        [Then(@"the user navigate to the My account page")]
        public void ThenTheUserNavigateToTheMyAccountPage()
        {
            page1.ValidateNavigation();
        }
    }  
}
